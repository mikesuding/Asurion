#!/usr/bin/python

import sys
import pysftp
import time
import datetime
import requests
import re
import ftplib
import json

#Obtain Args, prepare search pattern for python
fullSearchPatten = sys.argv[1]
serverAddress = sys.argv[2]
user_name = sys.argv[3]
pass_word = sys.argv[4]
pollSeconds = int(sys.argv[5])
pollTimes = int(sys.argv[6])
webhookURL = sys.argv[7]
includeWeb = sys.argv[8].lower() == 'true'
moveFile = sys.argv[9].lower() == 'true'
secureFtpRequired = sys.argv[10].lower() == 'true'

#Split fullname into path and name
fullSearchArr = fullSearchPatten.split('/')
fileSearchPatten = '^' + fullSearchArr[-1].replace('.','\\.').replace('*','[^/]*') + '$'
filePath = '/'.join(fullSearchArr[0:-1])
if filePath:
    filePath += '/'
detectedPath = filePath + 'detected'

if secureFtpRequired :
    cn_opts = pysftp.CnOpts()
    cn_opts.hostkeys = None
    sftp_client = pysftp.Connection(serverAddress, username = user_name, password = pass_word, cnopts=cn_opts)
else :
    ftp = ftplib.FTP(serverAddress)
    ftp.login(user = user_name, passwd = pass_word)


print ("Pooling every " + str(pollSeconds) + " seconds for " + str(pollTimes) + " times, looking for file " + fullSearchPatten)

for i in range(pollTimes):
    startDate = datetime.datetime.now()
    print("Poll " + str(i + 1) + " of " + str(pollTimes) + "... next poll in " + str(pollSeconds) + " seconds")

    if secureFtpRequired :
        listOfFiles = sftp_client.listdir(filePath)
    else :
        listOfFiles = []
        for singleFile in ftp.nlst(filePath):
            listOfFiles.append(singleFile.replace(filePath,''))
    
    #Compare file one-by-one
    for singleFile in listOfFiles:
        searchResult = re.match(fileSearchPatten, singleFile)
        if (searchResult) :
            fileName = searchResult.group(0)
            fullName = filePath + fileName
            print("Detected " + fullName + ", so calling job...")

            if moveFile:
                #MoveFile
                dateTimeNow = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
                newFullName = detectedPath + "/" + dateTimeNow + "-" + fileName

                if secureFtpRequired :
                    if not(sftp_client.exists(detectedPath)):
                        sftp_client.mkdir(detectedPath)
                    sftp_client.rename(fullName, newFullName)
                #No test path command in FTP library, check that this path presented in file list
                else :
                    if not('detected' in listOfFiles):
                        ftp.mkd(detectedPath)
                    ftp.rename(fullName, newFullName)

            else :
                #Move not required
                newFullName = fullName
            
            #Make request
            postData = json.dumps({'filename': newFullName})
            postHeaders = {'Content-typ':'application/json'}
            
            if includeWeb:
                requests.post(webhookURL, headers = postHeaders, data = postData)
            else:
                requests.post(webhookURL, headers = postHeaders)
            #Exit from Loop
            break
    
    #No matching files in this poll, slep for period
    endDate = datetime.datetime.now()
    secondsItTook = (endDate - startDate).total_seconds()
    time.sleep(pollSeconds - secondsItTook)

#Close client
if secureFtpRequired :
    sftp_client.close()
else :
    ftp.quit()

print ("Polling completed!")
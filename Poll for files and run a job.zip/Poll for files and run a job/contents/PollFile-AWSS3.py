#!/usr/bin/python

import boto3
import os
import time
import datetime
import requests
import sys
import re
import json

#Obtain Args, prepare search pattern for python
fullSearchPatten = sys.argv[1]
fullNameSearch = '^' + fullSearchPatten.replace('.','\\.').replace('*','[^/]*') + '$'
awsBucket = sys.argv[2]
accessId = sys.argv[3]
accessKey = sys.argv[4]
pollSeconds = int(sys.argv[5])
pollTimes = int(sys.argv[6])
webhookURL = sys.argv[7]
includeWeb = sys.argv[8].lower() == 'true'
moveFile = sys.argv[9].lower() == 'true'

s3_client = boto3.client('s3',
                         aws_access_key_id=accessId,
                         aws_secret_access_key=accessKey
                         )

print ("Pooling every " + str(pollSeconds) + " seconds for " + str(pollTimes) + " times, looking for file " + fullSearchPatten)

for i in range(pollTimes):
    startDate = datetime.datetime.now()
    print("Poll " + str(i + 1) + " of " + str(pollTimes) + "... next poll in " + str(pollSeconds) + " seconds")
    response = s3_client.list_objects_v2(
        Bucket=awsBucket
        )

    #get list of all items from bucket in full path format
    for singleFile in response['Contents']:
        #Perform regex search, if find, perform operations and exit from loop
        #TODO SearchResult shoul be convertable to bol
        searchResult = re.match(fullNameSearch, singleFile['Key'])
        
        if (searchResult) :
            #Discovered file, extract fullPath from match, call job 
            fullName = searchResult.group(0)
            print("Detected " + fullName + ", so calling job...")

            if moveFile:
                # Move file, prepare target directory and move file
                dateTimeNow = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
                fullNameArr = fullName.split('/')
                fileName = fullNameArr[-1]
                filePath = '/'.join(fullNameArr[0:-1])
                if filePath:
                    filePath += '/'
                detectedPath = filePath + 'detected'
                newFullName = detectedPath + "/" + dateTimeNow + "-" + fileName

                s3_resource = boto3.resource('s3',
                        aws_access_key_id=accessId,
                        aws_secret_access_key=accessKey
                        )
                copy_source = {
                    'Bucket': awsBucket,
                    'Key': fullName
                    }
                s3_resource.meta.client.copy(copy_source,awsBucket,newFullName)
                response = s3_client.delete_object(
                    Bucket=awsBucket,
                    Key=fullName
                )
            else :
                #Move not required
                newFullName = fullName
            #Make request
            postData = json.dumps({'filename': newFullName})
            postHeaders = {'Content-typ':'application/json'}
            
            if includeWeb:
                requests.post(webhookURL, headers = postHeaders, data = postData)
            else:
                requests.post(webhookURL, headers = postHeaders)
            #Exit from Loop
            break
    
    #No matching files in this poll, slep for period
    endDate = datetime.datetime.now()
    secondsItTook = (endDate - startDate).total_seconds()
    time.sleep(pollSeconds - secondsItTook)

print ("Polling completed!")
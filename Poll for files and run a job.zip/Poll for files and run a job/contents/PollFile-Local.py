#!/usr/bin/python

import os
import time
import datetime
import requests
import sys
import glob
import json

fullName = sys.argv[1]
pollSeconds = int(sys.argv[2])
pollTimes = int(sys.argv[3])
webhookURL = sys.argv[4]
includeWeb = sys.argv[5].lower() == 'true'
moveFile = sys.argv[6].lower() == 'true'

fullNameArr = fullName.split('/')
fileName = fullNameArr[-1]
filePath = '/'.join(fullNameArr[0:-1])
if filePath:
    filePath += '/'
detectedPath = filePath + 'detected'

print ("Pooling every " + str(pollSeconds) + " seconds for " + str(pollTimes) + " times, looking for file " + fullName)

for i in range(pollTimes):
    startDate = datetime.datetime.now()
    print("Poll " + str(i + 1) + " of " + str(pollTimes) + "... next poll in " + str(pollSeconds) + " seconds")
    
    target_files = glob.glob(fullName)

    if target_files:
        print("Detected " + target_files[0] + ", so calling job...")
        dateTimeNow = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

        if moveFile:
            fullNameArr = target_files[0].split(os.path.sep)
            fileName = fullNameArr[-1]
            filePath = os.path.sep.join(fullNameArr[0:-1])
            if filePath:
                filePath += os.path.sep
            detectedPath = filePath + 'detected'
            newFullName = detectedPath + os.path.sep + dateTimeNow + "-" + fileName

            if not(os.path.exists(detectedPath)):
                os.mkdir(detectedPath)
            os.rename(target_files[0], newFullName)
        else:
            newFullName = fullName
		
        postData = json.dumps({'filename': newFullName})
        postHeaders = {'Content-typ':'application/json'}

        if includeWeb:
            requests.post(webhookURL, headers = postHeaders, data = postData)
        else:
            requests.post(webhookURL, headers = postHeaders)
    
    endDate = datetime.datetime.now()
    secondsItTook = (endDate - startDate).total_seconds()
    time.sleep(pollSeconds - secondsItTook)
print ("Polling completed!")